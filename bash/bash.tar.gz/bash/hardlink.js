/**
 * =================
 * Transpiled with transpile.ts, see transpile.ignore
 * =================
 */
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import process from "node:process";
import { fileURLToPath } from "node:url";
const filename = path.basename(fileURLToPath(import.meta.url));
const th = (msg) => new Error(`${filename} error: ${msg}`);
function showHelp() {
  const helpText = `
Usage:
  node bash/hardlink.ts <path/to/config.md> [options]

Options:
  --pwd                     Resolve paths relative to current working directory (process.cwd())
  --pwd <path>              Resolve paths relative to explicit <path>
  --gitignore <path>        Path to .gitignore to ensure target file B paths are ignored
  --help, -h                Show this help page

Gitignore delimiters:
  If the target gitignore contains the block delimiters:
    # hardlink.ts vvv
    # hardlink.ts ^^^
  new file B entries (relative to gitignore) are inserted inside this block (if not already present).
  If either delimiter is missing, entries are appended to the end of the file.

Config file format:
  The config file defines pairs of paths separated by " -> " (one pair per line).
  Empty lines are allowed.
  Paths can be in plain text or markdown link format [label](path).
  Quotes can be used for paths with spaces.
  Tilde (~) expands to the current user's home directory.

Examples of valid pairs in config.md:
  [one](./lib/test.ts) -> [two](./bin/test.ts)
  [one](./node_modules/some_lib/test.ts) -> [two](somewhere else/test.ts)
  path/to/file.log -> [two](./bin/path/to/file2.log)
  [one](./test/ttt.sh) -> ./test/ttt2.sh
  "path/with/ spaces /file log.log" -> [two](./bin/path/with/ spaces /file log2.log)
  ~/.test/ttt.sh -> [in home user](./test/ttt2.sh)
`;
  console.log(helpText.trim());
  process.exit(1);
}
function expandHome(filePath) {
  if (filePath === "~") {
    return os.homedir();
  }
  if (filePath.startsWith("~/") || filePath.startsWith("~\\")) {
    return path.join(os.homedir(), filePath.slice(2));
  }
  return filePath;
}
function extractPathString(token) {
  let cleaned = token.trim();
  const mdMatch = cleaned.match(/^\[.*?\]\((.*)\)$/);
  if (mdMatch) {
    cleaned = mdMatch[1].trim();
  }
  if ((cleaned.startsWith('"') && cleaned.endsWith('"')) || (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
    cleaned = cleaned.slice(1, -1);
  }
  return cleaned;
}
function parseArgs(args) {
  const options = {};
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--help" || arg === "-h") {
      options.help = true;
    } else if (arg === "--pwd") {
      const nextArg = args[i + 1];
      if (nextArg && !nextArg.startsWith("-")) {
        options.pwdOverride = nextArg;
        i++;
      } else {
        options.useCwd = true;
      }
    } else if (arg === "--gitignore") {
      const nextArg = args[i + 1];
      if (nextArg && !nextArg.startsWith("-")) {
        options.gitignorePath = nextArg;
        i++;
      } else {
        console.error("Error: --gitignore requires a file path argument.");
        process.exit(1);
      }
    } else if (!arg.startsWith("-")) {
      if (!options.configFile) {
        options.configFile = arg;
      }
    }
  }
  return options;
}
function resolveBaseDir(configFilePath, options) {
  if (options.pwdOverride) {
    const resolved = path.resolve(process.cwd(), expandHome(options.pwdOverride));
    return {
      baseDir: resolved,
      reason: `--pwd parameter with explicit path "${options.pwdOverride}"`,
    };
  }
  if (options.useCwd) {
    return {
      baseDir: process.cwd(),
      reason: "--pwd flag using current working directory",
    };
  }
  const configDir = path.dirname(path.resolve(process.cwd(), expandHome(configFilePath)));
  return {
    baseDir: configDir,
    reason: `config.md location (${configDir})`,
  };
}
function isReadable(p) {
  try {
    fs.accessSync(p, fs.constants.R_OK);
    return true;
  } catch {
    return false;
  }
}
function isWritable(p) {
  try {
    fs.accessSync(p, fs.constants.W_OK);
    return true;
  } catch {
    return false;
  }
}
function canCreateInParent(filePath) {
  let curr = path.dirname(path.resolve(filePath));
  const toCheck = [];
  while (curr !== path.dirname(curr)) {
    if (fs.existsSync(curr)) {
      if (isWritable(curr)) {
        return { ok: true };
      }
      return { ok: false, error: `Directory "${curr}" is not writable.` };
    }
    toCheck.push(curr);
    curr = path.dirname(curr);
  }
  return { ok: false, error: `Cannot find existing writable ancestor directory for "${filePath}".` };
}
function parseConfigFile(content, baseDir) {
  const lines = content.split(/\r?\n/);
  const pairs = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      continue;
    }
    const match = trimmed.match(/^(.*?)\s+->\s+(.*)$/);
    if (match) {
      const rawA = extractPathString(match[1]);
      const rawB = extractPathString(match[2]);
      const expandedA = expandHome(rawA);
      const expandedB = expandHome(rawB);
      const resolvedA = path.resolve(baseDir, expandedA);
      const resolvedB = path.resolve(baseDir, expandedB);
      pairs.push({
        rawLine: line,
        rawA,
        rawB,
        resolvedA,
        resolvedB,
      });
    }
  }
  return pairs;
}
function updateGitignore(gitignoreFilePath, relativePathsToAdd) {
  let content = "";
  if (fs.existsSync(gitignoreFilePath)) {
    content = fs.readFileSync(gitignoreFilePath, "utf-8");
  }
  const startMarker = "# hardlink.ts vvv";
  const endMarker = "# hardlink.ts ^^^";
  const lines = content.split(/\r?\n/);
  const startIndex = lines.findIndex((l) => l.trim() === startMarker);
  const endIndex = lines.findIndex((l) => l.trim() === endMarker);
  const hasDelimiters = startIndex !== -1 && endIndex !== -1 && startIndex < endIndex;
  const added = [];
  if (hasDelimiters) {
    const insideLines = lines.slice(startIndex + 1, endIndex).map((l) => l.trim());
    const toInsert = [];
    for (const relPath of relativePathsToAdd) {
      if (!insideLines.includes(relPath)) {
        toInsert.push(relPath);
        added.push(relPath);
      }
    }
    if (toInsert.length > 0) {
      lines.splice(endIndex, 0, ...toInsert);
      fs.writeFileSync(gitignoreFilePath, lines.join("\n"), "utf-8");
      return { changed: true, added };
    }
    return { changed: false, added: [] };
  } else {
    const existingLines = lines.map((l) => l.trim());
    const toAppend = [];
    for (const relPath of relativePathsToAdd) {
      if (!existingLines.includes(relPath)) {
        toAppend.push(relPath);
        added.push(relPath);
      }
    }
    if (toAppend.length > 0) {
      let newContent = content;
      if (newContent.length > 0 && !newContent.endsWith("\n")) {
        newContent += "\n";
      }
      newContent += toAppend.join("\n") + "\n";
      fs.writeFileSync(gitignoreFilePath, newContent, "utf-8");
      return { changed: true, added };
    }
    return { changed: false, added: [] };
  }
}
async function run(args) {
  const options = parseArgs(args);
  if (options.help || !options.configFile) {
    showHelp();
  }
  const rawConfigPath = options.configFile;
  const configPath = path.resolve(process.cwd(), expandHome(rawConfigPath));
  if (!fs.existsSync(configPath)) {
    console.error(`Error: Config file "${rawConfigPath}" does not exist.`);
    process.exit(1);
  }
  let configStat;
  try {
    configStat = fs.statSync(configPath);
  } catch (err) {
    console.error(`Error: Cannot access config file "${rawConfigPath}": ${err.message}`);
    process.exit(1);
  }
  if (!configStat.isFile()) {
    console.error(`Error: Config path "${rawConfigPath}" is not a file.`);
    process.exit(1);
  }
  if (!isReadable(configPath)) {
    console.error(`Error: Config file "${rawConfigPath}" is not readable.`);
    process.exit(1);
  }
  const { baseDir, reason } = resolveBaseDir(rawConfigPath, options);
  console.log(`Resolved paths relative to: ${baseDir} (reason: ${reason})`);
  let resolvedGitignore;
  if (options.gitignorePath) {
    resolvedGitignore = path.resolve(process.cwd(), expandHome(options.gitignorePath));
    const parent = path.dirname(resolvedGitignore);
    if (!fs.existsSync(parent) || !isWritable(parent)) {
      console.error(`Error: Gitignore directory "${parent}" does not exist or is not writable.`);
      process.exit(1);
    }
    if (fs.existsSync(resolvedGitignore) && !isWritable(resolvedGitignore)) {
      console.error(`Error: Gitignore file "${resolvedGitignore}" is not writable.`);
      process.exit(1);
    }
  }
  const content = fs.readFileSync(configPath, "utf-8");
  const pairs = parseConfigFile(content, baseDir);
  const errors = [];
  for (const pair of pairs) {
    if (!fs.existsSync(pair.resolvedA)) {
      errors.push(`File A [${pair.rawA}] error:
   File does not exist: "${pair.resolvedA}"`);
      continue;
    }
    const statA = fs.statSync(pair.resolvedA);
    if (!statA.isFile()) {
      errors.push(`File A [${pair.rawA}] error:
   Path is not a regular file: "${pair.resolvedA}"`);
      continue;
    }
    if (!isReadable(pair.resolvedA)) {
      errors.push(`File A [${pair.rawA}] error:
   File is not readable: "${pair.resolvedA}"`);
      continue;
    }
    if (fs.existsSync(pair.resolvedB)) {
      const statB = fs.statSync(pair.resolvedB);
      if (!statB.isFile()) {
        errors.push(`File B [${pair.rawB}] error:
   Path is not a regular file: "${pair.resolvedB}"`);
        continue;
      }
      if (statA.dev === statB.dev && statA.ino === statB.ino) {
        continue;
      }
      if (!isReadable(pair.resolvedB)) {
        errors.push(`File B [${pair.rawB}] error:
   File is not readable: "${pair.resolvedB}"`);
        continue;
      }
      if (!isWritable(pair.resolvedB)) {
        errors.push(`File B [${pair.rawB}] error:
   File is not writable: "${pair.resolvedB}"`);
        continue;
      }
      const contentA = fs.readFileSync(pair.resolvedA);
      const contentB = fs.readFileSync(pair.resolvedB);
      if (!contentA.equals(contentB)) {
        errors.push(`File B [${pair.rawB}] error:
   Content of file B does not match content of file A`);
        continue;
      }
    } else {
      const parentB = path.dirname(pair.resolvedB);
      if (fs.existsSync(parentB)) {
        if (!isWritable(parentB)) {
          errors.push(`File B [${pair.rawB}] error:
   Parent directory "${parentB}" is not writable`);
          continue;
        }
      } else {
        const parentCheck = canCreateInParent(pair.resolvedB);
        if (!parentCheck.ok) {
          errors.push(`File B [${pair.rawB}] error:
   Cannot create parent directory for "${pair.resolvedB}": ${parentCheck.error}`);
          continue;
        }
      }
    }
  }
  if (errors.length > 0) {
    for (const err of errors) {
      console.error(err + "\n");
    }
    process.exit(1);
  }
  const isTTY = process.stdout.isTTY;
  const green = isTTY ? "\x1B[32m" : "";
  const reset = isTTY ? "\x1B[0m" : "";
  for (const pair of pairs) {
    console.log(pair.rawLine);
    const statA = fs.statSync(pair.resolvedA);
    if (fs.existsSync(pair.resolvedB)) {
      const statB = fs.statSync(pair.resolvedB);
      if (statA.dev === statB.dev && statA.ino === statB.ino) {
        console.log(`   Already linked (inode A: ${statA.ino}, inode B: ${statB.ino})`);
        continue;
      }
      fs.unlinkSync(pair.resolvedB);
      fs.linkSync(pair.resolvedA, pair.resolvedB);
      const newStatB = fs.statSync(pair.resolvedB);
      console.log(
        `   ${green}CHANGED${reset}: Replaced file B with hardlink to file A (inode A: ${statA.ino}, inode B: ${newStatB.ino})`
      );
    } else {
      const parentB = path.dirname(pair.resolvedB);
      if (!fs.existsSync(parentB)) {
        fs.mkdirSync(parentB, { recursive: true });
      }
      fs.linkSync(pair.resolvedA, pair.resolvedB);
      const newStatB = fs.statSync(pair.resolvedB);
      console.log(
        `   ${green}CHANGED${reset}: Created hardlink from file A to file B (inode A: ${statA.ino}, inode B: ${newStatB.ino})`
      );
    }
  }
  if (resolvedGitignore) {
    const gitignoreDir = path.dirname(resolvedGitignore);
    const relPathsToAdd = pairs.map((p) => {
      let rel = path.relative(gitignoreDir, p.resolvedB);
      rel = rel.split(path.sep).join("/");
      return rel;
    });
    console.log(`Gitignore check: "${resolvedGitignore}"`);
    const { changed, added } = updateGitignore(resolvedGitignore, relPathsToAdd);
    if (changed) {
      console.log(`   ${green}CHANGED${reset}: Added to gitignore:`);
      for (const entry of added) {
        console.log(`      + ${entry}`);
      }
    } else {
      console.log(`   No changes: all target paths already present in gitignore`);
    }
  }
}
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname)) {
  run(process.argv.slice(2)).catch((err) => {
    console.error(err.message);
    process.exit(1);
  });
}
export { expandHome, extractPathString, parseArgs, parseConfigFile, resolveBaseDir, run, showHelp, updateGitignore };

#!/usr/bin/env node
/**
 * =================
 * Transpiled with transpile.ts, see transpile.ignore
 * =================
 */
import fs from "node:fs/promises";
import readline from "node:readline";
const args = process.argv.slice(2);
const stream = args.includes("--forward-stdin-to-stdout");
const preambleFile = args.find((arg) => arg !== "--forward-stdin-to-stdout");
if (!preambleFile) {
  console.error("Usage: preamble.ts <preamble-file> [--forward-stdin-to-stdout]");
  process.exit(1);
}
const preamble = await fs.readFile(preambleFile, "utf8");
if (!preamble.trim()) {
  console.error(`Preamble file is empty: ${preambleFile}`);
  process.exit(1);
}
function addPreamble(source) {
  if (source.includes(preamble)) {
    return source;
  }
  const text = preamble.endsWith("\n")
    ? preamble
    : `${preamble}
`;
  if (source.startsWith("#!")) {
    const newline = source.indexOf("\n");
    if (newline === -1) {
      return `${source}
${text}`;
    }
    return `${source.slice(0, newline + 1)}${text}${source.slice(newline + 1)}`;
  }
  return `${text}${source}`;
}
function output(file) {
  if (stream) {
    console.log(file);
  } else {
    console.log(`preamble: ${file}`);
  }
}
const rl = readline.createInterface({
  input: process.stdin,
  terminal: false,
});
for await (const line of rl) {
  const file = line.trim();
  if (!file) {
    continue;
  }
  try {
    const source = await fs.readFile(file, "utf8");
    const updated = addPreamble(source);
    if (updated !== source) {
      await fs.writeFile(file, updated);
    }
    output(file);
  } catch (err) {
    if (!stream) {
      console.error(`preamble: failed ${file}`, err);
    }
    process.exitCode = 1;
  }
}
